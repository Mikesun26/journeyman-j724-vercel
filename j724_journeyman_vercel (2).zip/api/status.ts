import { toVercel } from './_adapter';
import * as fn from '../netlify/functions/status.js';
export default toVercel(fn as any);
