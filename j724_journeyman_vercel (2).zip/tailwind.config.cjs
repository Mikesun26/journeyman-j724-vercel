module.exports = {
  content: ["./index.html","./src/**/*.{ts,tsx}"],
  theme: { extend: { colors: { brand: { 500:"#06b6d4" } } } },
  plugins: []
}
